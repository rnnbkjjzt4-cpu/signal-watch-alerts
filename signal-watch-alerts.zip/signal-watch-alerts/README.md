# Signal Watch — free background alerts

Checks NOAA/NWS every 15 minutes for tornado, hurricane, and flood warnings
(and NASA FIRMS for fires, if you add a key), and emails/texts your subscriber
list when something new hits their watch area. Runs entirely on GitHub's free
Actions minutes — no server, no monthly bill.

## Setup (about 10 minutes)

1. **Create a GitHub repo** and push these files to it (or drag-and-drop upload
   via github.com → "Add file" → "Upload files").

2. **Gmail app password** (this is what sends the emails):
   - Turn on 2-Step Verification on the sending Gmail account:
     myaccount.google.com/security
   - Create an App Password: myaccount.google.com/apppasswords
   - Copy the 16-character password.

3. **Add repo secrets** — repo → Settings → Secrets and variables → Actions → New repository secret:
   - `GMAIL_USER` — the Gmail address sending alerts
   - `GMAIL_APP_PASSWORD` — the 16-char app password from step 2
   - `FIRMS_MAP_KEY` — optional, only if you want fire detections. Get one free
     at firms.modaps.eosdis.nasa.gov/api/map_key (instant, tied to your email)

4. **Edit `subscribers.json`** — replace the examples with real people:
   - `watchLocation` matches against the NWS alert's county/area text
     (e.g. `"Anoka"` catches "Anoka County, MN"). Keep it to a county or city name.
   - For fire alerts, a subscriber needs `lat`/`lon` — NWS county matching
     doesn't apply to satellite fire detections, proximity does.
   - `carrier` must be one of: verizon, att, tmobile, sprint, uscellular,
     boost, cricket, metropcs, googlefi. SMS goes out over the carrier's free
     email-to-SMS gateway — works, but not guaranteed and can get marked spam.
     Treat it as best-effort for a small list, not a scaled product.

5. **Turn it on** — the workflow (`.github/workflows/watch.yml`) is already set
   to run every 15 minutes once it's on GitHub. You can also trigger it by hand:
   repo → Actions tab → "Signal Watch — Alert Check" → "Run workflow".

## What's real vs. what's a placeholder

| Piece | Status |
|---|---|
| Tornado / hurricane / flood data | Live, free, no key needed (NOAA/NWS) |
| Fire data | Live if you add a free FIRMS key; skipped otherwise |
| Email delivery | Real, via your Gmail — free up to Gmail's own sending limits (~500/day) |
| SMS delivery | Real but unofficial (carrier email gateways) — free, best-effort |
| Damage $ estimates | Not included — no free real-time source exists |
| Subscriber signup form | Not built yet — right now you edit `subscribers.json` by hand |

## Natural next step

If this needs to scale past a hand-edited JSON file — actual public signups,
a subscriber count in the hundreds, guaranteed SMS delivery — that's the point
where it's worth paying for Twilio (SMS) and a small hosted database instead
of editing a file in GitHub. Everything here is free because it's small-scale
and best-effort by design.
